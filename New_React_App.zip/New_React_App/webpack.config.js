const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const NodePolyfillPlugin = require("node-polyfill-webpack-plugin");
const nodeExternals = require('webpack-node-externals');

module.exports = {
   target: 'node', // in order to ignore built-in modules like path, fs, etc.
   externalsPresets: { node: true },
   externals: [nodeExternals()], // in order to ignore all modules in node_modules folder
	resolve: {
        extensions: ['.js', '.jsx'],
        fallback: {
         fs: false,
         "child_process": false,
         "worker_threads" :false,
         "inspector" : false
       }
    },
    node : {
__dirname :false
    },
  // stats: 'errors-only',
 // stats :'detailed',
   entry: './index.js',
   output: {
      path: path.join(__dirname, '/bundle'),
      filename: 'index_bundle.js'
   },
   devServer: {
      // inline: false,
      // port: 8001
      inline: false,
      port: 8001,
      historyApiFallback: true
   },
   
   module: {
      rules: [
         {
            test: /\.jsx?$/,
            exclude: /node_modules/,
            loader: 'babel-loader',
            options: {
               presets: ["@babel/preset-env","@babel/preset-react"]
            }
         }
      ]
   },
   
  
   plugins:[
      new HtmlWebpackPlugin({
         template: './index.html'
      }),
      new NodePolyfillPlugin()
   ]
}


import React from 'react'
import { ProgressPlugin } from 'webpack';
import {buyCake} from '../redux'

function CakeContainer(props)
{
    
    return(

        <div>
            {/* <h2>Number of cakes -{props.numOfCakes} </h2>
            <button onClick={props.buyCake}>hi please buy cake</button> */}
            <h2>Number of cakes  </h2>
            <button >hi please buy cake</button>
        </div>
    )
}

const mapStateToProps = state =>
({
    numOfCakes: state.numOfCakes
    
});

const mapDispatchToProps = dispatch =>
({
    buyCake: () => dispatch(buyCake())
    
})
export default connect(mapStateToProps,mapDispatchToProps)  
(CakeContainer)
